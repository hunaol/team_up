<script setup>
import { onMounted, ref } from 'vue'
import { adminApi } from '../../api'
import { toast } from '../../toast'

const stats = ref(null)

onMounted(async () => {
  try {
    stats.value = await adminApi('/admin/stats')
  } catch (e) {
    toast(e.message, 'err')
  }
})
</script>

<template>
  <h2>数据概览</h2>
  <div v-if="!stats" class="empty">加载中…</div>
  <div v-else class="stat-grid">
    <div class="stat-card">
      <div class="num">{{ stats.user_count }}</div>
      <div class="label">注册用户数</div>
    </div>
    <div class="stat-card">
      <div class="num">{{ stats.post_total }}</div>
      <div class="label">帖子总数</div>
    </div>
    <div class="stat-card">
      <div class="num">{{ stats.team_count }}</div>
      <div class="label">找队友帖数</div>
    </div>
    <div class="stat-card">
      <div class="num">{{ stats.join_count }}</div>
      <div class="label">找队伍帖数</div>
    </div>
    <div class="stat-card">
      <div class="num">{{ stats.open_count }}</div>
      <div class="label">招募中帖数</div>
    </div>
  </div>
</template>
