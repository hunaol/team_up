<script setup>
import { onMounted, ref, watch } from 'vue'
import { adminApi } from '../../api'
import { toast } from '../../toast'
import { CONTACT_TEXT, STATUS_TEXT, TYPE_TEXT, relTime } from '../../utils'

const posts = ref([])
const loading = ref(true)
const typeFilter = ref('all')
const statusFilter = ref('all')
const keyword = ref('')

async function load() {
  loading.value = true
  try {
    const params = new URLSearchParams()
    if (typeFilter.value !== 'all') params.set('type', typeFilter.value)
    if (statusFilter.value !== 'all') params.set('status', statusFilter.value)
    if (keyword.value.trim()) params.set('q', keyword.value.trim())
    posts.value = await adminApi('/admin/posts?' + params.toString())
  } catch (e) {
    toast(e.message, 'err')
  } finally {
    loading.value = false
  }
}

async function takedown(p) {
  if (!confirm('下架后前台将不可见且不可恢复，确认下架？')) return
  try {
    await adminApi('/admin/posts/' + p.id + '/takedown', { method: 'POST' })
    toast('已下架')
    load()
  } catch (e) {
    toast(e.message, 'err')
  }
}

watch([typeFilter, statusFilter], load)
onMounted(load)
</script>

<template>
  <h2>帖子管理</h2>

  <div class="toolbar">
    <div class="tabs">
      <button :class="{ active: typeFilter === 'all' }" @click="typeFilter = 'all'">全部</button>
      <button :class="{ active: typeFilter === 'team' }" @click="typeFilter = 'team'">找队友</button>
      <button :class="{ active: typeFilter === 'join' }" @click="typeFilter = 'join'">找队伍</button>
    </div>
    <select v-model="statusFilter" style="border: 1px solid #cdd6e4; border-radius: 8px; padding: 6px 10px; font-size: 13px">
      <option value="all">全部状态</option>
      <option value="open">招募中</option>
      <option value="full">已招满</option>
      <option value="expired">已过期</option>
      <option value="down">已下架</option>
    </select>
    <div class="search-box">
      <input v-model="keyword" placeholder="搜索赛事名称 / 描述" @keyup.enter="load" />
      <button class="btn sm" @click="load">搜索</button>
    </div>
  </div>

  <div v-if="loading" class="empty">加载中…</div>
  <div v-else-if="!posts.length" class="empty">没有符合条件的帖子</div>
  <table v-else class="grid">
    <thead>
      <tr>
        <th>类型</th>
        <th>赛事名称</th>
        <th>发布者</th>
        <th>联系方式</th>
        <th>浏览量</th>
        <th>发布时间</th>
        <th>状态</th>
        <th>操作</th>
      </tr>
    </thead>
    <tbody>
      <tr v-for="p in posts" :key="p.id">
        <td><span class="tag" :class="p.type">{{ TYPE_TEXT[p.type] }}</span></td>
        <td>{{ p.title }}</td>
        <td>{{ p.author_name }}</td>
        <td>{{ CONTACT_TEXT[p.contact_type] ? CONTACT_TEXT[p.contact_type] + '：' : '' }}{{ p.contact }}</td>
        <td>{{ p.views }}</td>
        <td>{{ relTime(p.created_at) }}</td>
        <td><span class="tag" :class="p.status">{{ STATUS_TEXT[p.status] }}</span></td>
        <td>
          <button
            v-if="p.status === 'open' || p.status === 'full'"
            class="btn sm danger"
            @click="takedown(p)"
          >
            下架
          </button>
          <span v-else style="color: var(--sub)">—</span>
        </td>
      </tr>
    </tbody>
  </table>
</template>
