<script setup>
import { useRouter } from 'vue-router'
import { auth, logout } from '../store'

const router = useRouter()

async function onLogout() {
  await logout()
  router.push('/')
}
</script>

<template>
  <header class="nav">
    <div class="nav-inner">
      <router-link to="/" class="brand">
        <span class="logo">招</span>
        比赛队友招募
      </router-link>
      <router-link to="/" class="link">首页</router-link>
      <router-link to="/publish" class="link">发布招募</router-link>
      <template v-if="auth.user">
        <router-link to="/my" class="link">我的发布</router-link>
        <router-link to="/favorites" class="link">我的收藏</router-link>
      </template>
      <template v-if="auth.user">
        <span class="user-chip"><b>{{ auth.user.name }}</b>（{{ auth.user.student_id }}）</span>
        <button class="btn plain sm" @click="onLogout">退出</button>
      </template>
      <router-link v-else to="/login" class="btn sm">登录 / 注册</router-link>
    </div>
  </header>
</template>
