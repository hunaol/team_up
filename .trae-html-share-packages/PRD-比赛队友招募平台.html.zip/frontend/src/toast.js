import { reactive } from 'vue'

export const toastState = reactive({ show: false, text: '', type: 'ok' })

let timer = null
export function toast(text, type = 'ok') {
  toastState.show = true
  toastState.text = text
  toastState.type = type
  clearTimeout(timer)
  timer = setTimeout(() => {
    toastState.show = false
  }, 2500)
}
