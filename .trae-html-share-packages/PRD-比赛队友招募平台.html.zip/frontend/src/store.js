import { reactive } from 'vue'
import { api, setToken } from './api'

export const auth = reactive({
  user: JSON.parse(localStorage.getItem('user') || 'null')
})

export function setUser(u) {
  auth.user = u
  if (u) localStorage.setItem('user', JSON.stringify(u))
  else localStorage.removeItem('user')
}

export async function logout() {
  try {
    await api('/auth/logout', { method: 'POST' })
  } catch (e) {
    /* 忽略 */
  }
  setToken('')
  setUser(null)
}
