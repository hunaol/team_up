const BASE = '/api'

export function getToken() {
  return localStorage.getItem('token') || ''
}
export function setToken(t) {
  t ? localStorage.setItem('token', t) : localStorage.removeItem('token')
}
export function getAdminToken() {
  return localStorage.getItem('admin_token') || ''
}
export function setAdminToken(t) {
  t ? localStorage.setItem('admin_token', t) : localStorage.removeItem('admin_token')
}

function detailToMessage(detail) {
  if (!detail) return '请求失败，请稍后重试'
  if (typeof detail === 'string') return detail
  if (Array.isArray(detail)) {
    return detail.map((d) => d.msg || JSON.stringify(d)).join('；')
  }
  return JSON.stringify(detail)
}

export async function api(path, { method = 'GET', body, token } = {}) {
  const headers = {}
  if (body !== undefined) headers['Content-Type'] = 'application/json'
  const tk = token !== undefined ? token : getToken()
  if (tk) headers['Authorization'] = 'Bearer ' + tk
  let res
  try {
    res = await fetch(BASE + path, {
      method,
      headers,
      body: body !== undefined ? JSON.stringify(body) : undefined
    })
  } catch (e) {
    const err = new Error('网络异常，请检查连接')
    err.status = 0
    throw err
  }
  let data = null
  try {
    data = await res.json()
  } catch (e) {
    /* 无响应体 */
  }
  if (!res.ok) {
    const err = new Error(detailToMessage(data && data.detail))
    err.status = res.status
    throw err
  }
  return data
}

export function adminApi(path, opts = {}) {
  return api(path, { ...opts, token: getAdminToken() }).catch((err) => {
    if (err.status === 401) {
      setAdminToken('')
      location.assign('/admin/login')
    }
    throw err
  })
}
