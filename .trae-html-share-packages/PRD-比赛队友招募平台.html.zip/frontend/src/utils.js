export const TYPE_TEXT = { team: '找队友', join: '找队伍' }
export const STATUS_TEXT = { open: '招募中', full: '已招满', down: '已下架', expired: '已过期' }
export const CONTACT_TEXT = { wechat: '微信', qq: 'QQ', phone: '手机号' }
export const CONTACT_PLACEHOLDER = {
  wechat: '请输入微信号，如 wxid_abc123',
  qq: '请输入 5–12 位 QQ 号',
  phone: '请输入 11 位手机号'
}

export function isNew(iso) {
  const t = new Date(iso.endsWith('Z') ? iso : iso + 'Z')
  return Date.now() - t.getTime() < 86400 * 1000
}

export function relTime(iso) {
  const t = new Date(iso.endsWith('Z') ? iso : iso + 'Z')
  const diff = (Date.now() - t.getTime()) / 1000
  if (diff < 60) return '刚刚'
  if (diff < 3600) return Math.floor(diff / 60) + ' 分钟前'
  if (diff < 86400) return Math.floor(diff / 3600) + ' 小时前'
  if (diff < 86400 * 7) return Math.floor(diff / 86400) + ' 天前'
  return iso.slice(0, 10)
}

export async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text)
    return true
  } catch (e) {
    const ta = document.createElement('textarea')
    ta.value = text
    ta.style.position = 'fixed'
    ta.style.opacity = '0'
    document.body.appendChild(ta)
    ta.select()
    let ok = false
    try {
      ok = document.execCommand('copy')
    } catch (e2) {
      ok = false
    }
    document.body.removeChild(ta)
    return ok
  }
}
