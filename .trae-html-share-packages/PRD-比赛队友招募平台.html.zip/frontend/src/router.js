import { createRouter, createWebHistory } from 'vue-router'
import { getAdminToken, getToken } from './api'

const routes = [
  { path: '/', component: () => import('./views/Home.vue') },
  { path: '/post/:id', component: () => import('./views/PostDetail.vue') },
  { path: '/publish', component: () => import('./views/Publish.vue'), meta: { auth: true } },
  { path: '/my', component: () => import('./views/MyPosts.vue'), meta: { auth: true } },
  { path: '/favorites', component: () => import('./views/MyFavorites.vue'), meta: { auth: true } },
  { path: '/login', component: () => import('./views/Login.vue') },
  { path: '/admin/login', component: () => import('./views/admin/AdminLogin.vue') },
  {
    path: '/admin',
    component: () => import('./views/admin/AdminLayout.vue'),
    meta: { admin: true },
    children: [
      { path: '', component: () => import('./views/admin/AdminDashboard.vue') },
      { path: 'users', component: () => import('./views/admin/AdminUsers.vue') },
      { path: 'posts', component: () => import('./views/admin/AdminPosts.vue') }
    ]
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

router.beforeEach((to) => {
  if (to.meta.auth && !getToken()) {
    return { path: '/login', query: { redirect: to.fullPath } }
  }
  if (to.meta.admin && !getAdminToken()) {
    return { path: '/admin/login' }
  }
})

export default router
