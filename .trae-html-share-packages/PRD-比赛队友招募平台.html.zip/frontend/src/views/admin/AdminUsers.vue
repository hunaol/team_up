<script setup>
import { onMounted, ref } from 'vue'
import { adminApi } from '../../api'
import { toast } from '../../toast'

const users = ref([])
const loading = ref(true)
const keyword = ref('')

async function load() {
  loading.value = true
  try {
    const params = new URLSearchParams()
    if (keyword.value.trim()) params.set('q', keyword.value.trim())
    users.value = await adminApi('/admin/users?' + params.toString())
  } catch (e) {
    toast(e.message, 'err')
  } finally {
    loading.value = false
  }
}

async function toggle(u) {
  if (u.active && !confirm('停用后该用户将无法登录和发布，确认停用？')) return
  try {
    const action = u.active ? 'deactivate' : 'activate'
    await adminApi('/admin/users/' + u.id + '/' + action, { method: 'POST' })
    toast(u.active ? '已停用' : '已启用')
    load()
  } catch (e) {
    toast(e.message, 'err')
  }
}

onMounted(load)
</script>

<template>
  <h2>用户管理</h2>

  <div class="toolbar">
    <div class="search-box" style="margin-left: 0">
      <input v-model="keyword" placeholder="按学号 / 姓名搜索" @keyup.enter="load" />
      <button class="btn sm" @click="load">搜索</button>
    </div>
  </div>

  <div v-if="loading" class="empty">加载中…</div>
  <div v-else-if="!users.length" class="empty">未找到用户</div>
  <table v-else class="grid">
    <thead>
      <tr>
        <th>学号</th>
        <th>姓名</th>
        <th>发帖数</th>
        <th>注册时间</th>
        <th>状态</th>
        <th>操作</th>
      </tr>
    </thead>
    <tbody>
      <tr v-for="u in users" :key="u.id">
        <td>{{ u.student_id }}</td>
        <td>{{ u.name }}</td>
        <td>{{ u.post_count }}</td>
        <td>{{ u.created_at.slice(0, 10) }}</td>
        <td>
          <span class="tag" :class="u.active ? 'ok' : 'ban'">
            {{ u.active ? '正常' : '停用' }}
          </span>
        </td>
        <td>
          <button class="btn sm" :class="u.active ? 'danger' : 'ghost'" @click="toggle(u)">
            {{ u.active ? '停用' : '启用' }}
          </button>
        </td>
      </tr>
    </tbody>
  </table>
</template>
