<script setup>
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import NavBar from './components/NavBar.vue'
import { toastState } from './toast'

const route = useRoute()
const isAdmin = computed(() => route.path.startsWith('/admin'))
</script>

<template>
  <NavBar v-if="!isAdmin" />
  <router-view />
  <footer v-if="!isAdmin" class="footer">
    比赛队友招募平台 · 联系方式仅登录用户可见 · 帖子有效期 30 天
  </footer>
  <div v-if="toastState.show" class="toast" :class="{ err: toastState.type === 'err' }">
    {{ toastState.text }}
  </div>
</template>
