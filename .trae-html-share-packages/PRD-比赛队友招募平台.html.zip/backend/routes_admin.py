from datetime import datetime, timedelta
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, or_
from sqlalchemy.orm import Session

from auth import hash_password, issue_token, require_admin
from database import get_db
from models import EXPIRE_DAYS, Admin, Post, Token, User, effective_status
from routes_post import post_out
from schemas import AdminLoginIn

router = APIRouter()


@router.post("/login")
def admin_login(body: AdminLoginIn, db: Session = Depends(get_db)):
    a = db.query(Admin).filter(Admin.username == body.username).first()
    if not a or hash_password(body.password, a.salt) != a.password_hash:
        raise HTTPException(status_code=401, detail="账号或密码不正确")
    return {"token": issue_token(db, is_admin=True)}


@router.get("/stats")
def stats(_: Token = Depends(require_admin), db: Session = Depends(get_db)):
    expire_before = datetime.utcnow() - timedelta(days=EXPIRE_DAYS)
    user_count = db.query(func.count(User.id)).scalar()
    post_total = db.query(func.count(Post.id)).scalar()
    team_count = db.query(func.count(Post.id)).filter(Post.type == "team").scalar()
    join_count = db.query(func.count(Post.id)).filter(Post.type == "join").scalar()
    open_count = (
        db.query(func.count(Post.id))
        .filter(Post.status == "open", Post.created_at > expire_before)
        .scalar()
    )
    return {
        "user_count": user_count,
        "post_total": post_total,
        "team_count": team_count,
        "join_count": join_count,
        "open_count": open_count,
    }


@router.get("/users")
def list_users(
    q: Optional[str] = None,
    _: Token = Depends(require_admin),
    db: Session = Depends(get_db),
):
    query = db.query(User)
    if q:
        like = f"%{q}%"
        query = query.filter(or_(User.student_id.like(like), User.name.like(like)))
    users = query.order_by(User.created_at.desc()).all()
    counts = dict(
        db.query(Post.user_id, func.count(Post.id)).group_by(Post.user_id).all()
    )
    return [
        {
            "id": u.id,
            "student_id": u.student_id,
            "name": u.name,
            "active": u.active,
            "post_count": counts.get(u.id, 0),
            "created_at": u.created_at.isoformat(),
        }
        for u in users
    ]


@router.post("/users/{user_id}/deactivate")
def deactivate_user(user_id: int, _: Token = Depends(require_admin), db: Session = Depends(get_db)):
    u = db.get(User, user_id)
    if not u:
        raise HTTPException(status_code=404, detail="用户不存在")
    u.active = False
    db.query(Token).filter(Token.user_id == u.id, Token.is_admin == False).delete()  # noqa: E712
    db.commit()
    return {"ok": True}


@router.post("/users/{user_id}/activate")
def activate_user(user_id: int, _: Token = Depends(require_admin), db: Session = Depends(get_db)):
    u = db.get(User, user_id)
    if not u:
        raise HTTPException(status_code=404, detail="用户不存在")
    u.active = True
    db.commit()
    return {"ok": True}


@router.get("/posts")
def list_posts(
    type: Optional[str] = None,
    status: Optional[str] = None,
    q: Optional[str] = None,
    _: Token = Depends(require_admin),
    db: Session = Depends(get_db),
):
    query = db.query(Post)
    if type in ("team", "join"):
        query = query.filter(Post.type == type)
    if q:
        like = f"%{q}%"
        query = query.filter(or_(Post.title.like(like), Post.description.like(like)))
    posts = query.order_by(Post.created_at.desc()).all()
    result = [post_out(p, True) for p in posts]
    if status in ("open", "full", "down", "expired"):
        result = [r for r in result if r["status"] == status]
    return result


@router.post("/posts/{post_id}/takedown")
def takedown_post(post_id: int, _: Token = Depends(require_admin), db: Session = Depends(get_db)):
    p = db.get(Post, post_id)
    if not p:
        raise HTTPException(status_code=404, detail="帖子不存在")
    if effective_status(p) not in ("open", "full"):
        raise HTTPException(status_code=400, detail="当前状态不可下架")
    p.status = "down"
    db.commit()
    return post_out(p, True)
