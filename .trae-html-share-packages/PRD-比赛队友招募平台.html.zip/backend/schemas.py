import re
from typing import Literal, Optional

from pydantic import BaseModel, Field, model_validator


class RegisterIn(BaseModel):
    student_id: str = Field(min_length=5, max_length=20, pattern=r"^[A-Za-z0-9]+$")
    name: str = Field(min_length=2, max_length=20)


class LoginIn(BaseModel):
    student_id: str = Field(min_length=1, max_length=20)
    name: str = Field(min_length=1, max_length=20)


class PostIn(BaseModel):
    type: Literal["team", "join"]
    title: str = Field(min_length=2, max_length=50)
    description: str = Field(min_length=10, max_length=500)
    need_num: Optional[int] = Field(default=None, ge=1, le=99)
    contact_type: Literal["wechat", "qq", "phone"] = "wechat"
    contact: str = Field(min_length=5, max_length=100)

    @model_validator(mode="after")
    def check_contact(self):
        self.contact = self.contact.strip()
        if len(self.contact) < 5:
            raise ValueError("联系方式至少 5 个字符")
        if self.contact_type == "qq" and not re.fullmatch(r"\d{5,12}", self.contact):
            raise ValueError("QQ 号需为 5–12 位数字")
        if self.contact_type == "phone" and not re.fullmatch(r"1[3-9]\d{9}", self.contact):
            raise ValueError("手机号格式不正确")
        return self


class AdminLoginIn(BaseModel):
    username: str = Field(min_length=1, max_length=30)
    password: str = Field(min_length=1, max_length=64)
